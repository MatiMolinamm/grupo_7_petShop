# grupo_7_petShop

Proyecto Integrador Digital House

URL DEL REPOSITORIO
https://github.com/MatiMolinamm/grupo_7_petShop.git

URL DEL TRELLO
https://trello.com/b/Ei16JNvi/spring-1-proyecto-integrador-digital-house

PROYECTO INTEGRADOR PETIT AND FUN - PETSHOP -

PRESENTACIóN
https://www.canva.com/design/DAE8Y-rq0ZM/CYEuYDIHcoeUiv7lCVz0DA/view?utm_content=DAE8Y-rq0ZM&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton

¿QUÉ PRODUCTOS O SERVICIOS BRINDARÁ NUESTRO SITIO?
Nuestro sitio web ofrece productos y servicios para gran variedad de mascotas.

Desde perros y gatos hasta aves y peces Con alimentos balanceados, comestibles, juguetes y accesorios...

- Alimentos balanceados
- juguetes
- accesorios

¿QUIÉN SERÁ NUESTRA AUDIENCIA OBJETIVO?
Nuestro público o audiencia objetivo, son aquellos amantes de sus mascotas, que consideran que ellas son su bien más preciado y su momento de diversión, por eso eligen lo mejor para ellos: Una buena alimentación con productos de calidad y juguetes que les permitan interactuar con ellos.

¿CÓMO AJUSTAREMOS NUESTRA OFERTA A ESE PÚBLICO?
En PetitandFun entendemos que nuestros usuarios no solo buscan un producto sino un momento para recrear el vínculo. Por ello nuestro sitio ofrece servicios y un reseñas para ayudarlos a mejorar ese vínculo y un servicio de entrega de productos a domicilio, para que la única preocupación sea su mascota. Nuestro sitio web permite adquirir una variedad de productos y servicios como contactarnos para recibir asesoramiento inmediato.

NOSOTROS
Somos un equipo de emprendedores entusiastas que entendemos el vínculo entre una persona y su mascota, creeemos que llevar productos y servicios de calidad a traves de una plataforma entretenida es la mejor forma de satisfacer esa necesidad.

Nuestro DEV Team, está compuesto por:

- Luca Santino Murarotto - vivo en la provincia de Buenos Aires, tengo un zoo en casa.
- Luca Spiritini - vivo en CABA, acróbata, dos perros.
- Mariano Javier Gecelewicz - un programador entusiasta y empedernido.
- Matias Molina - de Villa Nueva Córdoba me gustan los perro y el padel.
- Miguel Caputo - soy de zona sur, Avellaneda, tengo una tortuga.

SITIOS WEB DE REFERENCIA
https://www.puppis.com.ar/
Un sitio con mucha información y gran cantidad de productos y promociones

https://www.petmarket.com.ar/
Simple y sencilla, visualmente atractiva

https://www.natural-life.com.ar/
Otro sitio simple visualmente pero muy sencilla de navegar

https://www.petmania.com.ar/
Muy amigable e intuitivo

https://www.catycan.com/
Variedad de alternativas en productos para todos los consumidores de productos para mascotas
