Este es el archivo "RETRO.md", aquí dejaremos constancia de los errores y aprendizajes:

En este archivo nos hacemos tres preguntas:

- Que salió bien?
- Hubo algún problema? Cuál fué su posible causa?
- Como podríamos hacerlo mejor?

----    SPRINT 1    ----

El resultado fue bueno en general, además mejoramos la forma de ordenar el trabajo en Trello, asignando uno o más compañeros por tarea

Organizamos dos reuniones extraordinarias de 1:30hs cada una en donde expusimos ideas, dimos opinión de cada una, se eligieron las que se creían eran las mejores, para luego variarla o adecuarla.

A pesar de las tareas diarias de cada compañero pactamos un día a la semana para reunion grupal, luego ocurrieron reuniones de menos miembros cada vez que alguien necesitaba algún consejo en particular.

La tarea pendiente era agregar la descripción de cada integrante al archivo README, lo resolvimos en la primer reunion luego de la devolucion del Sprint1, cada integrante escribió en Discord una línea, luego un compañero lo agregó al repositorio. Fué el único pendiendo del Sprint1, se nos pasó, por no tenerla escrita en Trello.